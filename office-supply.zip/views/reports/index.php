<div class="text-center">
    <h2><?= $this->title ?></h2>
    <p>Выберите отчёт из меню выше.</p>
</div>
