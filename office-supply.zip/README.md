# Отчёты Office Supply

Проект **Office Supply** — система управления заказами, продуктами и договорами организаций, разработанная на **Yii2**.  
Цель проекта — автоматизация учёта и создание удобных динамических отчётов для анализа данных.

---

## 📑 Реализованные отчёты

В приложении реализовано **5 аналитических отчётов**:

1. **Цена ручек "черная, гелевая"**  
   Показывает товары с описанием, содержащим слова «черная» и «гелевая».

2. **Продукция по договорам в выбранном месяце**  
   По умолчанию — сентябрь, но можно выбрать любой месяц.

3. **Заказы организаций (по названию)**  
   Фильтрация заказов по организации.

4. **Количество заказов организаций**  
   Для каждой организации выводится количество сделанных заказов.  
   Есть динамический фильтр по «минимальному количеству заказов».

5. **Организации с более чем N договорами**  
   Позволяет указать минимальное количество договоров (например, 2).

Все отчёты имеют формы фильтрации, основанные на модели `SearchForm`.

---

## 📦 CRUD-функционал

Система поддерживает полноценные CRUD-операции для всех сущностей:

- **Organizations**
- **Products**
- **Contracts**
- **Sales**

Каждая модель имеет:

- формы создания и редактирования,
- таблицы просмотра данных (GridView),
- фильтрацию,
- связи между моделями (`hasMany` / `hasOne`).

---

## 🔐 Авторизация

В проекте существует учётная запись администратора:

Логин: admin
Пароль: password

Администратор имеет полный доступ ко всем CRUD и отчётам.

## 🔗 Доступ к CRUD и отчётам

### CRUD

Все сущности доступны для администратора по следующим адресам:

- **Организации (Organizations)**: [http://localhost:8080/admin/organization](http://localhost:8080/admin/organization)
- **Продукты (Products)**: [http://localhost:8080/admin/product](http://localhost:8080/admin/product)
- **Договоры (Contracts)**: [http://localhost:8080/admin/contract](http://localhost:8080/admin/contract)
- **Заказы (Sales)**: [http://localhost:8080/admin/sale](http://localhost:8080/admin/sale)

### Отчёты

Отчёты доступны по следующим маршрутам:

- **Цена ручек "черная, гелевая"**: [http://localhost:8080/reports/price-pens](http://localhost:8080/reports/price-pens)
- **Продукция по договорам в сентябре**: [http://localhost:8080/reports/orders-september](http://localhost:8080/reports/orders-september)
- **Заказы организаций по названию**: [http://localhost:8080/reports/orders-by-organization](http://localhost:8080/reports/orders-by-organization)
- **Количество заказов организаций**: [http://localhost:8080/reports/orders-count](http://localhost:8080/reports/orders-count)
- **Организации с более чем N договорами**: [http://localhost:8080/reports/organizations-with-contracts](http://localhost:8080/reports/organizations-with-contracts)

---

## 🛠 Установка и запуск

### 1. Клонировать проект

```bash
git clone https://github.com/Biomorinnio/office-supply.git
cd office-supply
```

### 2. Установить зависимости

```bash
composer install
```

### 3. Создать базу данных

```bash
CREATE DATABASE office_supply CHARACTER SET utf8 COLLATE utf8_general_ci;
```

### 4. Импортировать дамп базы

В phpMyAdmin → Импорт → выбрать файл office_supply.sql.

### 5. Настроить подключение к базе

Файл: config/db.php

```bash
return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=office_supply',
    'username' => 'root',
    'password' => '',
    'charset' => 'utf8',
];
```

```bash
6. Запустить проект
php yii serve
```

Перейти в браузере по адресу:

http://localhost:8080

📂 Основная структура проекта
office-supply/
│
├── assets/ # Сборка CSS/JS
├── config/ # Настройки приложения
├── controllers/ # Контроллеры, включая ReportsController
├── models/ # ActiveRecord модели
├── views/ # Интерфейс CRUD и отчётов
├── web/ # Web-root приложения
├── office_supply.sql # Дамп базы данных
└── README.md

📊 Маршруты отчётов

Отчёты доступны по следующим маршрутам:

/reports/price-pens
/reports/orders-september
/reports/orders-by-organization
/reports/orders-count
/reports/organizations-with-contracts

Ссылки на отчёты также доступны через меню навигации.

📌 Автор

Разработчик: Biomorinnio (Крысанов Д.О.)
GitHub: https://github.com/Biomorinnio
